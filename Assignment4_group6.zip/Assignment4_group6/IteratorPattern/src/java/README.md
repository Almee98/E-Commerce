# The source code of the iterator pattern implements depicts the following:
  -  choice of categories selected by the user
  -  for the selected catogory the products in its sub category are displayed or iterated
  -  App.java file in the src folder contains the driver code.
  
# Steps to run the code
  - In the console, specify the path to src folder and give the following commands:
    - javac App.java 
    - java App
  

## Output of the implementation is:

<img width="1300" alt="output" src="https://user-images.githubusercontent.com/79885052/165043421-a7109c38-3661-4fe0-a73d-fa3d19ab445c.png">

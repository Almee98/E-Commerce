package shipmentSubsystem;

public class Shipment {
    public String createShipment() {
        return "Shipment is created.";
    }
}

package paymentSubsystem;

public class Payment {
    public String verifyPaymentDetails() {
        return "Payment details are verified. Payment process completed.";
    }
}

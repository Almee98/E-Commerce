package inventorySubsystem;

public class Product {
    public int productAmount(int productId) {
        return 40;
    }
}

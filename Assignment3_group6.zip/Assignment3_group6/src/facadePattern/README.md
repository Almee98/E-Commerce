# The `Assignment3_group6` folder consists of the following:
  - `src/facadePattern` : Implementation of Facade Design Pattern in java
  - `Facade_Design_Pattern.pdf` (text file for facade pattern)
  - `Facede_Pattern_Class_Diagram.jpeg` (Class Diagram)
  - `Facade_Pattern_Sequence_Diagram.jpeg` (Sequence Diagram)

## Output of the implementation is:

![output](https://user-images.githubusercontent.com/79885052/163752178-ca68b562-e742-4abd-8272-4d8d496069eb.png)
